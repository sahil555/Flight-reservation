﻿# airline
airline reservation system
open with url: http://localhost:600/airline/

1) You need to export the .sql file in database folder
2) Then Copy the whole airline folder into php folder 
(example mamp/htdocs) and open the above URl. Please make sure you use port 600.
3) All other details are provided in report file under README folder




Contributors:

Aman Miryala
Akash Patti

## Creators
**SRI HARSHA GANJA**

* <https://github.com/ganjash>

**Mark Otto**

* <https://twitter.com/mdo>
* <https://github.com/mdo>

**Jacob Thornton**

* <https://twitter.com/fat>
* <https://github.com/fat>


## Copyright and license

Code and documentation copyright 2011-2015 Twitter, Inc. Code released under [the MIT license](https://github.com/twbs/bootstrap/blob/master/LICENSE). Docs released under [Creative Commons](https://github.com/twbs/bootstrap/blob/master/docs/LICENSE).

