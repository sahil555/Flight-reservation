<?php

echo "Sorry you're details are not saved" ;

?>